# ==============================================================================
# ⚡ ESO:LAUNCHER - ZSH ENGINE CONFIGURATION
# ==============================================================================

# Enable Powerlevel10k instant prompt if available
if [[ -r "${XDG_CACHE_HOME:-$HOME/.cache}/p10k-instant-prompt-${(%):-%n}.zsh" ]]; then
  source "${XDG_CACHE_HOME:-$HOME/.cache}/p10k-instant-prompt-${(%):-%n}.zsh"
fi

# Path to Oh My Zsh if installed
export ZSH="$HOME/.oh-my-zsh"

# Set Powerlevel10k Theme
if [ -d "$HOME/.oh-my-zsh/custom/themes/powerlevel10k" ]; then
    ZSH_THEME="powerlevel10k/powerlevel10k"
elif [ -f "$HOME/.zsh/themes/powerlevel10k/powerlevel10k.zsh-theme" ]; then
    source "$HOME/.zsh/themes/powerlevel10k/powerlevel10k.zsh-theme"
fi

# Oh My Zsh Loader (if present)
if [ -f "$ZSH/oh-my-zsh.sh" ]; then
    plugins=(git zsh-autosuggestions zsh-syntax-highlighting)
    source "$ZSH/oh-my-zsh.sh"
fi

# Load Powerlevel10k Configuration
[[ ! -f ~/.p10k.zsh ]] || source ~/.p10k.zsh

# ------------------------------------------------------------------------------
# HISTORY CONFIGURATION (Lengkap & Tahan Banting)
# ------------------------------------------------------------------------------
HISTFILE="$HOME/.zsh_history"
HISTSIZE=10000
SAVEHIST=10000
setopt APPEND_HISTORY
setopt INC_APPEND_HISTORY
setopt SHARE_HISTORY
setopt HIST_IGNORE_DUPS
setopt HIST_IGNORE_ALL_DUPS
setopt HIST_REDUCE_BLANKS
setopt HIST_FIND_NO_DUPS
setopt HIST_SAVE_NO_DUPS

# ------------------------------------------------------------------------------
# KEYBINDINGS & HISTORY PREFIX SEARCH (Panah Atas / Bawah ala Hacker)
# ------------------------------------------------------------------------------
bindkey -e
autoload -Uz up-line-or-beginning-search down-line-or-beginning-search
zle -N up-line-or-beginning-search
zle -N down-line-or-beginning-search
bindkey '^[[A' up-line-or-beginning-search
bindkey '^[[B' down-line-or-beginning-search
bindkey '^[OA' up-line-or-beginning-search
bindkey '^[OB' down-line-or-beginning-search

bindkey ' ' magic-space                           
bindkey '^U' backward-kill-line                   
bindkey '^[[3;5~' kill-word                       
bindkey '^[[3~' delete-char                       
bindkey '^[[1;5C' forward-word                    
bindkey '^[[1;5D' backward-word                   
bindkey '^[[5~' beginning-of-buffer-or-history    
bindkey '^[[6~' end-of-buffer-or-history          
bindkey '^[[H' beginning-of-line                  
bindkey '^[[F' end-of-line                        
bindkey '^[[Z' undo                               
bindkey '^[[C' forward-char
bindkey '^[OC' forward-char

# ------------------------------------------------------------------------------
# WARNA UNTUK LESS & MAN PAGES
# ------------------------------------------------------------------------------
export LESS_TERMCAP_mb=$'\E[1;31m'
export LESS_TERMCAP_md=$'\E[1;36m'
export LESS_TERMCAP_me=$'\E[0m'
export LESS_TERMCAP_so=$'\E[01;33m'
export LESS_TERMCAP_se=$'\E[0m'
export LESS_TERMCAP_us=$'\E[1;32m'
export LESS_TERMCAP_ue=$'\E[0m'
export MANROFFOPT="-c"

# ------------------------------------------------------------------------------
# SMART AUTOCOMPLETION
# ------------------------------------------------------------------------------
autoload -Uz compinit
compinit -d "$HOME/.zcompdump"
zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*:descriptions' format '%F{yellow}-- %d --%f'

# ------------------------------------------------------------------------------
# ZSH PLUGINS (Autosuggestions & Syntax Highlighting Standalone Fallback)
# ------------------------------------------------------------------------------
if [ -f "$HOME/.oh-my-zsh/custom/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh" ]; then
    source "$HOME/.oh-my-zsh/custom/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh"
elif [ -f "$HOME/.zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh" ]; then
    source "$HOME/.zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh"
elif [ -f "$PREFIX/share/zsh-autosuggestions/zsh-autosuggestions.zsh" ]; then
    source "$PREFIX/share/zsh-autosuggestions/zsh-autosuggestions.zsh"
fi
ZSH_AUTOSUGGEST_STRATEGY=(history completion)
ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=244'

if [ -f "$HOME/.oh-my-zsh/custom/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]; then
    source "$HOME/.oh-my-zsh/custom/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"
elif [ -f "$HOME/.zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]; then
    source "$HOME/.zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"
elif [ -f "$PREFIX/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]; then
    source "$PREFIX/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"
fi

# ------------------------------------------------------------------------------
# TERMUX IPC HELPER & AUTOCOMPLETION
# ------------------------------------------------------------------------------
paste() {
    if [ $# -eq 0 ]; then
        termux-ipc clip-get
    else
        command paste "$@"
    fi
}

_termux() {
    local -a commands
    commands=(
        'kb:Kontrol soft keyboard (hide, show, on, off)'
        'mouse:Mode touch mouse (on, off, toggle)'
        'toast:Tampilkan popup notifikasi Android Toast'
        'notif:Kirim notifikasi ke status bar Android'
        'notification:Kirim notifikasi ke status bar Android'
        'copy:Salin teks ke clipboard Android'
        'paste:Cetak teks dari clipboard Android'
        'torch:Kontrol lampu senter LED (on, off)'
        'battery:Cek persentase dan status baterai'
        'vibrate:Picu getaran haptic HP'
        'vol:Atur volume audio media (0-15)'
        'wifi:Info status jaringan WiFi aktif'
        'browser:Buka atau kelola WebView Fusion'
        'launcherctl:Saklar LauncherCtl Daemon (on, off, status)'
        'gui:Jalankan Cyberpunk Touch GUI'
        'gui-stop:Hentikan Cyberpunk Touch GUI'
        'ping:Cek koneksi socket server IPC'
        'help:Tampilkan panduan bantuan termux'
    )
    if (( CURRENT == 2 )); then
        _describe -t commands 'perintah termux' commands
    elif (( CURRENT == 3 )) && [[ "${words[2]}" == "launcherctl" ]]; then
        local -a lctl_cmds
        lctl_cmds=('on:Aktifkan LauncherCtl daemon' 'off:Matikan LauncherCtl daemon (0% CPU)' 'status:Cek status LauncherCtl')
        _describe -t lctl_cmds 'opsi launcherctl' lctl_cmds
    fi
}
compdef _termux termux

_kb() {
    local -a kb_cmds
    kb_cmds=('hide:Sembunyikan keyboard' 'show:Munculkan keyboard' 'on:Aktifkan keyboard' 'off:Matikan keyboard')
    _describe -t kb_cmds 'opsi keyboard' kb_cmds
}
compdef _kb kb

_mouse() {
    local -a mouse_cmds
    mouse_cmds=('on:Aktifkan mouse' 'off:Nonaktifkan mouse' 'toggle:Toggle mouse')
    _describe -t mouse_cmds 'opsi mouse' mouse_cmds
}
compdef _mouse mouse

_torch() {
    local -a torch_cmds
    torch_cmds=('on:Nyalakan senter' 'off:Matikan senter')
    _describe -t torch_cmds 'opsi senter' torch_cmds
}
compdef _torch torch

# ------------------------------------------------------------------------------
# PROJECT FUSION ENVIRONMENT & ALIASES
# ------------------------------------------------------------------------------
[ -f "$HOME/.fusion_env" ] && source "$HOME/.fusion_env"

alias c=clear
alias python=python3
alias p=python3
alias ls="ls --color=auto"
alias grep="grep --color=auto"
alias fgrep="fgrep --color=auto"
alias egrep="egrep --color=auto"
alias diff="diff --color=auto"
alias ip="ip --color=auto"
alias ll="ls -l"
alias la="ls -A"
alias l="ls -CF"
alias wallet="wallet"
alias patchright="node ./wallet/patchright.js"
alias x="x"
alias xradar="node ~/wallet/x_webview.js"
alias browser="termux-ipc webview"
alias ipc="termux-ipc"
alias copilot="agy-copilot"
alias bashnh="bashnh"
alias login="login"
